<?php

date_default_timezone_set('Asia/Manila');

$conn = new PDO('mysql:host=localhost;dbname=qrCodeGen', 'root', '');
 
?>
